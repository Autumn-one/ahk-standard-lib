# ahk-standard-lib

autohotkey语言的标准库,目标是提供更好的数据结构操作体验.项目开源,欢迎参与.

## string 字符串相关方法

- Split 切割字符串返回一个数组
- Length 返回字符串的长度
- StartsWith 判断字符串是否以某个子字符串开头
- EndsWith
